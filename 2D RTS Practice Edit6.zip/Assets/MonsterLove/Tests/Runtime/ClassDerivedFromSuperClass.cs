﻿using UnityEngine;
using System.Collections;
using MonsterLove.StateMachine;

public class ClassDerivedFromSuperClass : ClassWithBasicStates
{
}
