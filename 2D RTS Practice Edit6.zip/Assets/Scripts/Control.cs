using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Control : MonoBehaviour
{
    public List<GameObject> playerlist = new List<GameObject>();
    public List<GameObject> enemyllist = new List<GameObject>();
    public List<GameObject> attacking = new List<GameObject>();
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
