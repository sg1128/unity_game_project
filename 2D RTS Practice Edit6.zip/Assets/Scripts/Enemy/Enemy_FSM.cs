using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MonsterLove.StateMachine;

public class Enemy_FSM : MonoBehaviour
{
    Enemy enemy;
    public GameObject target;
    float DelayTime = 4f;
    float startTime = 0;
    public float currentTime = 0;
    public bool fight = false;
    bool on = false;
    public enum CharacterStates
    {
        Idle,
        Move,
        Attack,
        Attacked,
        Death
    }
    private StateMachine<CharacterStates, StateDriverUnity> fsm;
    void Start()
    {
        enemy = gameObject.GetComponent<Enemy>();
        fsm = new StateMachine<CharacterStates, StateDriverUnity>(this);
        fsm.ChangeState(CharacterStates.Idle);
    }

    void Update()
    {
        fsm.Driver.Update.Invoke();
    }

    void Idle_Enter()
    {
    }
    void Idle_Update()
    {
        if (fight)
        {
            if (on == false)
            {
                on = true;
                StartCoroutine(Enemy_Delay());
            }
        }

        //if (gameObject.GetComponent<Heal_Unitmovement>().arrived == false)
        //{
        //    fsm.ChangeState(CharacterStates.Move);
        //}

        //if (target == null)
        //{
        //    if (targetList.Count > 0)
        //    {
        //        target = targetList[0];
        //        fight = true;
        //    }
        //}
        //else
        //{
        //    FoundTarget();
        //}
        //if (fight)
        //{
        //    if (currentTime >= DelayTime)
        //    {
        //        if (on == false)
        //        {
        //            on = true;
        //            StartCoroutine(Delay());
        //        }
        //    }
        //}
    }
    void Move_Enter()
    {
    }

    void Move_Update()
    {
        if (gameObject.GetComponent<Heal_Unitmovement>().arrived == true)
        {
            fsm.ChangeState(CharacterStates.Idle);
        }
        //�̵��ϴ� ���߿��� �������� ��� �i�ư�
        //if (target != null)
        //{
        //    FoundTarget();
        //}
        //if (targetList.Count > 0)
        //{
        //    if (heal_unitmovement.only_move == false)
        //    {
        //        player_move = false;
        //        heal_unitmovement.PlayerStop();
        //    }
        //}
    }
    void Attack_Enter()
    {
        StartCoroutine(Enemy_Attack());
    }
    void Attack_Update()
    {
        //if (gameObject.GetComponent<Heal_Unitmovement>().arrived == false)
        //{
        //    fsm.ChangeState(CharacterStates.Move);
        //}
    }


    void Death_Enter()
    {
        //Unit Destroy()
    }

    private void OnTriggerStay2D(Collider2D col)
    {
        if(col.gameObject.layer == LayerMask.NameToLayer("Clickable"))
        {
            fight = true;
            fsm.ChangeState(CharacterStates.Attack);
        }
    }

    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.gameObject.layer == LayerMask.NameToLayer("Clickable"))
            fight = false;
    }

    IEnumerator Enemy_move()
    {
        this.gameObject.transform.position = Vector2.MoveTowards(this.gameObject.transform.position, target.transform.position, 3 * Time.deltaTime);
        StopCoroutine(Enemy_move());
        yield return 0;
    }

    IEnumerator Enemy_Attack()
    {
        // �����ϴ� �ð�
        yield return new WaitForSeconds(1.0f);
        // Ÿ���� �ִٸ� Ÿ���� �������� ����
        if (target != null)
            target.GetComponent<Unit>().TakeDamage(enemy.dmg);
        fsm.ChangeState(CharacterStates.Idle);
        StopCoroutine(Enemy_Attack());
    }

    IEnumerator Enemy_Delay()
    {
        // �������� ���� �ð�
        yield return new WaitForSeconds(DelayTime);
        on = false;
        fsm.ChangeState(CharacterStates.Attack);
        StopCoroutine(Enemy_Delay());
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "dps" || col.gameObject.tag =="tank" || col.gameObject.tag =="heal")
        {
            // ���ݸ��� ����
        }
    }
}
